package com.fnproject.fn.examples.service;

import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class BankCalendarService {
	
	public List<LocalDate> getBankHolidays(){
		return Arrays.asList(
				LocalDate.of(LocalDate.now().getYear(),Month.JANUARY,1),
				LocalDate.of(LocalDate.now().getYear(),Month.MAY,1),
				LocalDate.of(LocalDate.now().getYear(),Month.JUNE,6),
				LocalDate.of(LocalDate.now().getYear(),Month.AUGUST,15),
				LocalDate.of(LocalDate.now().getYear(),Month.DECEMBER,25),
				LocalDate.of(LocalDate.now().getYear(),Month.DECEMBER,31));
	}
	

}
