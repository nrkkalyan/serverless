package com.fnproject.fn.examples;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.function.context.config.ContextFunctionCatalogAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.fnproject.fn.api.FnConfiguration;
import com.fnproject.fn.api.FunctionInvoker;
import com.fnproject.fn.api.RuntimeContext;
import com.fnproject.fn.examples.service.BankCalendarService;
import com.fnproject.springframework.function.SpringCloudFunctionInvoker;

import lombok.extern.slf4j.Slf4j;

@Configuration
@SpringBootApplication
@Import(ContextFunctionCatalogAutoConfiguration.class)
@Slf4j
public class SCFExample {

	@Autowired
	private BankCalendarService bankCalendarService;

	public static void main(String[] args) {
		SpringApplication.run(SCFExample.class, args);
	}

	@FnConfiguration
	public static void configure(RuntimeContext ctx) {
		ctx.addInvoker(new SpringCloudFunctionInvoker(SCFExample.class), FunctionInvoker.Phase.Call);
	}

	// Unused - see https://github.com/fnproject/fdk-java/issues/113
	public void handleRequest() {
	}

	@Bean
	public Function<String, List<LocalDate>> getBankHolidays() {
		return str -> bankCalendarService.getBankHolidays();
	}

	@Bean
	public Function<String, LocalDateTime> function() {
		return (input) -> {
			log.info("Received input as :{}. This method only consumes, and CANNOT return anything.", input);
			return LocalDateTime.now();
		};
	}

	@Bean
	public Consumer<String> consumer() {
		return (input) -> {
			log.info("Received input as :{}. This method only consumes, and CANNOT return anything.", input);
		};
	}

	@Bean
	public Supplier<LocalDateTime> supplier() {
		return () -> {
			log.info("This method cannot receive any INPUTS. Only Return some value");
			return LocalDateTime.now();
		};
	}
}
